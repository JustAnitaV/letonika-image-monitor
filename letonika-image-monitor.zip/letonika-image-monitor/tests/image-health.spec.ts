import { test } from '@playwright/test';
import nodemailer from 'nodemailer';

const TARGET_URL = process.env.TARGET_URL || 'https://letonika.lv';
const ALERT_TO = process.env.ALERT_TO || 'anita.vas@icloud.com';
const ALERT_FROM = process.env.ALERT_FROM;
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;

const INCLUDE_SELECTORS = (process.env.IMAGE_SELECTORS || 'img')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

const EXCLUDE_SELECTORS = (process.env.EXCLUDE_SELECTORS || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

const MIN_RENDERED_WIDTH = Number(process.env.MIN_RENDERED_WIDTH || 20);
const MIN_RENDERED_HEIGHT = Number(process.env.MIN_RENDERED_HEIGHT || 20);
const DEBUG_OK = process.env.DEBUG_OK === 'true';

function escapeHtml(input: string): string {
  return input
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

type BrokenImage = {
  src: string;
  alt: string;
  selector: string;
  reason: string;
  pageTitle: string;
  pageUrl: string;
  width: number;
  height: number;
  naturalWidth: number;
  naturalHeight: number;
};

async function sendAlertEmail(brokenImages: BrokenImage[]) {
  if (!SMTP_USER || !SMTP_PASS || !ALERT_FROM) {
    throw new Error('Missing SMTP_USER, SMTP_PASS or ALERT_FROM secret.');
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS,
    },
  });

  const subject = `[Letonika monitor] Atrastas problēmas ar attēliem (${brokenImages.length})`;
  const text = [
    `Lapas pārbaude atrada ${brokenImages.length} problēmu(-as) ar attēliem.`,
    `URL: ${TARGET_URL}`,
    '',
    ...brokenImages.map((item, index) => {
      return [
        `${index + 1}. ${item.reason}`,
        `   src: ${item.src || '(nav src)'}`,
        `   alt: ${item.alt || '(nav alt)'}`,
        `   izmērs: ${item.width}x${item.height}`,
        `   natural: ${item.naturalWidth}x${item.naturalHeight}`,
        `   page: ${item.pageUrl}`,
      ].join('\n');
    }),
  ].join('\n');

  const htmlItems = brokenImages
    .map(
      (item, index) => `
        <li style="margin-bottom:12px;">
          <strong>${index + 1}. ${escapeHtml(item.reason)}</strong><br>
          src: <code>${escapeHtml(item.src || '(nav src)')}</code><br>
          alt: <code>${escapeHtml(item.alt || '(nav alt)')}</code><br>
          izmērs: <code>${item.width}x${item.height}</code><br>
          natural: <code>${item.naturalWidth}x${item.naturalHeight}</code><br>
          lapa: <code>${escapeHtml(item.pageUrl)}</code>
        </li>
      `,
    )
    .join('');

  await transporter.sendMail({
    from: ALERT_FROM,
    to: ALERT_TO,
    subject,
    text,
    html: `
      <div style="font-family:Arial,sans-serif; font-size:14px; line-height:1.5;">
        <p><strong>Letonika monitorings</strong> atrada ${brokenImages.length} problēmu(-as) ar attēliem.</p>
        <p>URL: <a href="${escapeHtml(TARGET_URL)}">${escapeHtml(TARGET_URL)}</a></p>
        <ol>${htmlItems}</ol>
      </div>
    `,
  });
}

test('letonika.lv: attēli nav salūzuši un nav tukši', async ({ page }) => {
  const brokenImages: BrokenImage[] = [];

  await page.goto(TARGET_URL, { waitUntil: 'domcontentloaded', timeout: 90_000 });
  await page.waitForLoadState('networkidle', { timeout: 30_000 }).catch(() => {});
  await page.waitForTimeout(5000);

  const pageTitle = await page.title();

  const selector = INCLUDE_SELECTORS.join(', ');
  const images = page.locator(selector);
  const count = await images.count();

  for (let i = 0; i < count; i++) {
    const img = images.nth(i);

    const info = await img.evaluate((el: Element) => {
      const htmlImg = el as HTMLImageElement;
      const rect = htmlImg.getBoundingClientRect();
      const style = window.getComputedStyle(htmlImg);
      const src = htmlImg.currentSrc || htmlImg.src || '';
      const alt = htmlImg.alt || '';
      const selector = htmlImg.tagName.toLowerCase();

      return {
        src,
        alt,
        complete: htmlImg.complete,
        naturalWidth: htmlImg.naturalWidth || 0,
        naturalHeight: htmlImg.naturalHeight || 0,
        width: Math.round(rect.width),
        height: Math.round(rect.height),
        display: style.display,
        visibility: style.visibility,
        opacity: style.opacity,
      };
    });

    if (EXCLUDE_SELECTORS.length) {
      const excluded = await img.evaluate(
        (el, selectors) => selectors.some((selector) => el.matches(selector)),
        EXCLUDE_SELECTORS,
      );
      if (excluded) continue;
    }

    const isHidden =
      info.display === 'none' ||
      info.visibility === 'hidden' ||
      Number(info.opacity) === 0;

    const hasNoSource = !info.src;
    const brokenLoad = !info.complete || info.naturalWidth === 0 || info.naturalHeight === 0;
    const emptySpace = !isHidden && (info.width < MIN_RENDERED_WIDTH || info.height < MIN_RENDERED_HEIGHT);

    let reason = '';
    if (hasNoSource) reason = 'Attēlam nav src/currentSrc';
    else if (brokenLoad) reason = 'Attēls nav korekti ielādējies';
    else if (emptySpace) reason = `Attēls ir pārāk mazs vai tukšs (${info.width}x${info.height})`;

    if (reason) {
      brokenImages.push({
        src: info.src,
        alt: info.alt,
        selector: selector,
        reason,
        pageTitle,
        pageUrl: TARGET_URL,
        width: info.width,
        height: info.height,
        naturalWidth: info.naturalWidth,
        naturalHeight: info.naturalHeight,
      });
    }
  }

  if (DEBUG_OK || brokenImages.length > 0) {
    console.log(`Pārbaudīti attēli: ${count}`);
    console.log(`Atrastas problēmas: ${brokenImages.length}`);
  }

  if (brokenImages.length > 0) {
    await sendAlertEmail(brokenImages);
    throw new Error(
      `Atrastas ${brokenImages.length} problēmas ar attēliem. E-pasts nosūtīts uz ${ALERT_TO}.`,
    );
  }
});
