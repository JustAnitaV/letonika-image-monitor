# Letonika image monitor

Šis projekts katru dienu plkst. **00:01 pēc Londonas laika** atver `https://letonika.lv`, pārbauda attēlus un nosūta e-pastu uz `anita.vas@icloud.com`, ja kāds attēls nav ielādējies vai izskatās kā tukša vieta.

## Kas tiek pārbaudīts

Katram atlasītajam `img` elementam skripts pārbauda:
- vai attēlam ir `src` vai `currentSrc`;
- vai tas ir pabeidzis ielādi;
- vai `naturalWidth` un `naturalHeight` nav 0;
- vai renderētais izmērs nav pārāk mazs vai tukšs.

Tā kā Letonika attēli mainās, skripts **nesalīdzina attēlu saturu ar vakardienu**. Tas pārbauda tikai to, vai attēls ir korekti ielādēts un nav tukša vieta.

## 1. Izveido GitHub repozitoriju

Izveido jaunu repozitoriju, piemēram: `letonika-image-monitor`.

## 2. Ieliec šos failus repozitorijā

Augšupielādē visus šī projekta failus.

## 3. Ieslēdz Gmail App Password

Nodemailer Gmail sūtīšanai iesaka izmantot **Google App Password**, nevis parasto Gmail paroli. Tam vajag ieslēgt **2-Step Verification** Google kontam.

Pēc tam izveido 16 simbolu App Password.

## 4. GitHub Secrets

Repozitorijā atver:

**Settings → Secrets and variables → Actions**

Izveido šādus secrets:

- `SMTP_USER` — Tavs Gmail, piemēram `tavs.epasts@gmail.com`
- `SMTP_PASS` — Gmail App Password
- `ALERT_FROM` — no kā sūtīt, piemēram `Letonika monitors <tavs.epasts@gmail.com>`

## 5. Ieslēdz Actions

Atver cilni **Actions** un palaid workflow vienu reizi ar **Run workflow**, lai notestētu uzreiz.

## 6. Ja vajag atlasīt tikai konkrētus attēlus

Šobrīd workflow pārbauda visus `img` elementus:

```yml
IMAGE_SELECTORS: img
```

Ja vēlāk gribi pārbaudīt tikai konkrētus blokus, vari to nomainīt, piemēram:

```yml
IMAGE_SELECTORS: '.hero img, .article-card img, .banner img'
```

## 7. Ko darīt, ja ir viltus trauksmes

Dažkārt lapā ir ļoti mazi tehniski attēli, ikonveida attēli vai lazy-load elementi. Tad ir 3 varianti:

1. samazināt vai palielināt minimālo izmēru;
2. izmantot šaurāku `IMAGE_SELECTORS`;
3. pievienot `EXCLUDE_SELECTORS` konkrētiem elementiem.

Piemērs:

```yml
EXCLUDE_SELECTORS: '.logo img, .tracking-pixel, .social-icon img'
```

## Piezīme par GitHub schedule

GitHub Actions scheduled workflow var darboties pēc cron grafika, pēc noklusējuma UTC, un atbalsta arī laika joslu. Minimālais intervāls ir 5 minūtes. Šajā projektā iestatīts `00:01 Europe/London`.
